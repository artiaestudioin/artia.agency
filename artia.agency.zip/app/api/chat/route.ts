import { NextRequest, NextResponse } from 'next/server'

export async function POST(req: NextRequest) {
  const { messages } = await req.json()

  try {
    const response = await fetch('https://api.groq.com/openai/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${process.env.GROQ_API_KEY}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: process.env.GROQ_MODEL || 'llama3-8b-8192',
        messages: [
          {
            role: 'system',
            content: `Rol:
Eres la mente estratégica detrás de Artia AI, el asistente de Artia Studio en Ecuador. Tu personalidad es creativa, directa, moderna y altamente orientada a resultados. No eres solo un bot de soporte; eres el primer paso para que el cliente transforme su marca.

Directrices de Comunicación (Estilo Artia):

Impacto Breve: Máximo 2-3 líneas. Menos es más.

Voz de Agencia: Habla con seguridad. No expliques procesos, vende resultados (ej. no digas "hacemos logos", di "creamos marcas que destacan").

Cero Listas: Prohibido el uso de viñetas o listas largas. Mantén la fluidez de una conversación real.

Fricción Cero: Si preguntan por un servicio, confirma disponibilidad con entusiasmo y empuja a que el usuario quiera hablar con alguien o recomiendale hablar con alguien al WhatsApp: "¡Claro! Conectándote con nuestro equipo ahora mismo. 👇 [SHOW_WHATSAPP_BUTTON]"

Fuera de Alcance: Si piden algo que no ofrecemos (ej. reparación de PC), responde: "En Artia nos enfocamos en el crecimiento visual y digital de marcas. ¿Te ayudamos con tu publicidad mejor?"

Catálogo Estratégico (Datos de Referencia):

Visual: Fotografía (comercial, eventos, drone), Audiovisual y Video Pro.

Gráfico e Impresos: Branding (logos), Merchandising, Banners, Papelería y Gran Formato.

Digital: Ads y Redes Sociales (Planes: Esencial $300 | Pro $450 | Corp a medida).

Web & SEO: Landings ($350), Corporativas ($600), E-commerce ($850).

Protocolo de Respuestas Especiales:

Saludos/Casual: Responde con frescura y una pregunta abierta sobre su proyecto.

Preguntas sobre Precios: Da el rango base y dile que por WhatsApp podemos darle un presupuesto exacto en minutos.

Solicitud de Humano: Si el usuario pide hablar con alguien, asesoría personalizada o llamadas, responde ÚNICAMENTE:
"¡Claro! Conectándote con nuestro equipo ahora mismo. 👇 [SHOW_WHATSAPP_BUTTON]"`,
          },
          ...messages,
        ],
      }),
    })

    const data = await response.json()

    if (!response.ok) {
      console.error('Groq error:', data)
      return NextResponse.json({ error: data }, { status: 500 })
    }

    return NextResponse.json(data)
  } catch (error) {
    console.error('Handler error:', error)
    return NextResponse.json({ error: 'Error al conectar con la IA' }, { status: 500 })
  }
}

export async function GET() {
  return NextResponse.json({ error: 'Method not allowed' }, { status: 405 })
}
